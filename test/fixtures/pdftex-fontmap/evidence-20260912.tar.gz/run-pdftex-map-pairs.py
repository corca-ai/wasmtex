import subprocess
from pathlib import Path
root=Path('/Users/ak/prjs/cc/wasmtex-pdftex-fontmap')
for case in ['article','math-fonts','multi-file']:
 for pair in range(5):
  for variant in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
   out=Path(f'/tmp/pdftex-fontmap-pairs/{case}/{pair}-{variant}')
   out.mkdir(parents=True,exist_ok=True)
   cmd=['node','scripts/profile-font-cpu.mjs','--assets',f'/tmp/pdftex-fontmap-assets/{variant}','--engine','pdflatex','--year','2025','--texlive-url','https://texlive.corca.ai/snapshots/2025-0d3fc73b65e39905/2025/','--trace','false','--repetitions','1','--out',str(out)]
   if case!='article':cmd+=['--project',f'/tmp/pdftex-fontmap-fixtures/{case}.json']
   with (out/'run.log').open('w') as log:subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
   print(case,pair,variant,flush=True)
