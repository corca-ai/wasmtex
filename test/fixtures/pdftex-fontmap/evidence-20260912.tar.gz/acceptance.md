## Scope and decision rule

Investigate pdfTeX font-map construction under the existing engine optimization
policy. The current published pdfTeX executable matches the named diagnostic
binary's non-custom WASM sections. Prior sampling identifies repeated AVL
lookup/insertion work as one part of map loading; this must be rechecked.

Candidate: avoid duplicate AVL searches for append/ignore-duplicate map entries,
while retaining the same AVL tree, insertion order, duplicate warnings, map
replacement/deletion, PS-name links, memory reset and error behavior. No parsed
font objects are retained across compiles. Keep source pins, toolchain, mirrors,
base format bytes and consumer-visible TeX Live choices unchanged.

Before candidate measurement: require at least 5% median whole-compile gain on
representative map-heavy full compiles, repeated in alternating baseline/candidate
runs. Reject meaningful regressions (over 5% or 5 ms, whichever is larger) in
unaffected/checkpoint paths, output or diagnostic differences, excessive memory
cost, or a benefit confined to synthetic tree microbenchmarks. Check article,
font/math-heavy and multi-file documents; distinguish first/preamble/full body
compile from actual checkpoint resume. Qualify both annual lines before release.

Use exact source, native differential tests of actual map registration, then
rebuilt WASM with original formats. Publish only after standalone artifact/source,
browser/Node compatibility and performance gates pass; consumer adoption remains
CorTeX-owned. If the candidate fails, retain evidence and close as not adopted.
