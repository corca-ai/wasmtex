import json,statistics,sys
from pathlib import Path
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent/'reports'
fields=['success','typesetSha256','pdfBytes','artifacts','synctexPresent','errors','diagnostics','geometry','log','dependencies','pdfConversionInputs','glyphCoverage','preambleSnapshot','preambleRebuilt']
summary={};count=0
for case in ['article','math-fonts','multi-file']:
 rows={}
 for i in range(5):
  reports=[json.loads((root/case/f'{i}-{v}'/'report.json').read_text()) for v in ['baseline','candidate']]
  a,b=reports
  for field in ['year','mirror','browser','node','platform','architecture','harnessSha256','project']: assert a.get(field)==b.get(field),field
  assert not a.get('error') and not b.get('error')
  assert not a['traceEnabled'] and not b['traceEnabled']
  assert a['assetHashes'].keys()==b['assetHashes'].keys()
  for name,h in a['assetHashes'].items():
   if name not in ['wasmtex-pdftex.js','wasmtex-pdftex.wasm','wasmtex-pdftex-checkpoint.js','wasmtex-pdftex-checkpoint.wasm']:assert b['assetHashes'][name]==h,name
  samples=[[s for s in r['samples'] if s['measured']] for r in reports]
  assert all(len(s)==1 for s in samples)
  stages=[s[0]['stages'] for s in samples]
  assert [s['stage'] for s in stages[0]]==['init','first','repeat','body-edit','preamble-edit']
  assert len(stages[0])==len(stages[1])
  for x,y in zip(*stages):
   assert x['stage']==y['stage']
   for field in fields:assert x.get(field)==y.get(field),(case,i,x['stage'],field)
   req=lambda s:[(q['url'],q['status']) for q in s['requests']]
   assert req(x)==req(y)
   for s in (x,y):
    assert not any(q.get('error') or q['source'] in ['upstream','blocked-miss'] for q in s['requests'])
    if s['stage']!='init':assert '(preloaded format=pdflatex)' in s['log']
   if x['stage']!='init':count+=1
   rows.setdefault(x['stage'],[]).append((x['ms'],y['ms']))
 summary[case]={}
 for stage,pairs in rows.items():
  b,c=[statistics.median(p[j] for p in pairs) for j in (0,1)]
  summary[case][stage]={'baselineMs':b,'candidateMs':c,'improvementPercent':100*(b-c)/b,'pairs':pairs}
print(json.dumps({'compatibleCompiles':count,'summary':summary},indent=2))
