# pdfTeX font-map single-probe experiment

Issue: https://github.com/corca-ai/wasmtex/issues/138
SDK baseline: 08c1394 (origin/main at experiment start).
Engine source: 143f1723353b20202645f241db429b080a8adcdf (2025).
The two pinned years have identical mapfile.c (SHA-256
349e3078008137395ed59a9c4694c2708a0cc5fcceea4263bcd46f6f8b20b051).

The candidate changes append/ignore-duplicate registration to use avl_probe
once. Tree count distinguishes existing from newly inserted records. The AVL
implementation/layout/order, replace/delete paths and diagnostic strings remain.
No map contents, original formats, mirror objects or SDK runtime are changed.

Actual upstream registration, comparators, record definitions, flag macros,
destructors and avl.c are compiled in the native differential. Each variant
executes four resets and 12,000 operations per reset, comparing warnings,
operation results and ordered tree contents. This is not a full parser test.
macOS plain and Linux GCC ASan/UBSan pass with output SHA-256
5ec56ca868f69fdd47b85ae67ba606807909cd781463b8ac6ef05188802539c0.
macOS ASan stalls before main in sanitizer initialization (sample retained),
so it is not counted as passing coverage or a pdfTeX failure.

Builds run from the pinned-source, Emscripten 3.1.46 Docker environment on
neverland. Current tracked build inputs are copied into the container. Baseline
build completes before the patch is applied with --fuzz=0; the candidate then
runs the same Makefile wasm-compile target. Both ordinary/checkpoint binaries
are produced. Baseline WASM is byte-identical to the released 2025 workflow
33882993861 artifacts; the original release fmt is used unchanged on both sides.
These experimental artifacts have no release receipts and are not publishable.

Browser measurement uses scripts/profile-font-cpu.mjs with tracing disabled,
one measured fresh context after each preparation context, five alternating
pairs per document. Preparation downloads missing mirror responses; measured
contexts reject upstream misses. First/preamble stages include cached loopback
HTTP transfers, while repeat/body stages have zero requests. Timings exclude
post-compile hashing and are not production navigation-to-PDF measurements.
The 2026 named profile only confirms hotspot attribution: all non-custom WASM
sections equal the current published pdfTeX. Traced timings are not speedups.

The declaration in issue #138 precedes candidate measurements: at least 5%
median whole-compile improvement on representative map-heavy full compiles;
reject significant unaffected-path regressions or observable output differences.
The corpus covers article, Palatino math/fonts, and multi-file report documents.
No result from a tree-only microbenchmark qualifies an engine release.

## Decision

Not adopted: all 60 measured compile pairs match PDFs, SyncTeX/auxiliary files,
diagnostics, logs, dependencies and file requests, but no measured compilation
stage in any of the three document groups reaches the declared 5% improvement.
Whole-compile gains range from 0.59% to 4.04%. Initialization variation is not a
font-map speedup. No 2026 candidate, full Node/browser release qualification or
consumer transition is pursued after this failed performance gate. No engine
release, SDK runtime change, or CorTeX change is adopted.

Reproduce the evidence comparison with `python3 compare.py`. To rerun the native
differential, use `candidate-source/scripts/test-pdftex-fontmap.py --source DIR
--sanitize --cc gcc`, where DIR contains mapfile.c, avl.c, avl.h, ptexlib.h and
ptexmac.h from the pinned source. The measured browser runner is the unchanged
repository `scripts/profile-font-cpu.mjs` at the SDK revision above; the archived
pair driver records exact commands and paths. Recreate those temporary asset
paths from the original workflow artifacts and the two source builds before
rerunning. `build-inputs/` contains the actual build inputs and candidate patch.
The archive omits copyrighted mirror payloads and experimental WASM binaries;
reports retain all relevant hashes. Candidate-source is evidence, not active
engine build input. There are no new persistent objects or tree allocations;
WASM size grows by 212 bytes (ordinary) / 390 bytes (checkpoint).
