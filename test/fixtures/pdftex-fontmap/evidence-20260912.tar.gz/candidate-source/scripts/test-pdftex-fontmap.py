#!/usr/bin/env python3
"""Differentially execute upstream map registration and AVL code, not a model."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import tempfile

p = argparse.ArgumentParser()
p.add_argument('--source', type=Path, required=True)
p.add_argument('--cc', default='clang')
p.add_argument('--sanitize', action='store_true')
a = p.parse_args()
root = Path(__file__).resolve().parent.parent
source = (a.source / 'mapfile.c').read_text()
header = (a.source / 'ptexlib.h').read_text()
macros = (a.source / 'ptexmac.h').read_text()

def section(text, start, end):
    assert text.count(start) == 1, start
    i = text.index(start)
    return text[i:text.index(end, i)]

def unit(text):
    prefix = '''#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"
typedef bool boolean;
typedef int integer;
typedef void subfont_entry;
#define xtalloc(n,t) ((t *)calloc(n,sizeof(t)))
#define xfree free
#define FD_FLAGS_NOT_SET_IN_MAPLINE -1
#define cmp_return(a,b) if((a)>(b))return 1; if((a)<(b))return -1
static int suppress_warn;
static int getpdfsuppresswarningdupmap(void) { return suppress_warn; }
static void pdftex_warn(const char *fmt, ...) {
 va_list args; va_start(args,fmt); vprintf(fmt,args); va_end(args); puts("");
}
static const char nontfm[] = "<nontfm>";
typedef enum { FM_DUPIGNORE, FM_REPLACE, FM_DELETE } updatemode;
struct avl_table *tfm_tree, *ps_tree;
'''
    struct = section(header, 'typedef struct {\n    /* parameters scanned from the map file:', '} fm_entry;') + '} fm_entry;\n'
    flags = section(macros, '#  define F_INCLUDED ', '#  define set_cur_file_name')
    alloc = section(text, 'fm_entry *new_fm_entry(void)', 'static ff_entry *new_ff_entry')
    compare = section(text, 'static int comp_fm_entry_tfm(', '/* AVL sort ff_entry')
    start = 'static fm_entry *fm_find_or_insert(' if 'static fm_entry *fm_find_or_insert(' in text else 'int avl_do_entry('
    register = section(text, start, 'static char *add_encname')
    destroy = section(text, 'static void destroy_fm_entry_tfm(', 'static void destroy_ff_entry(')
    return prefix + struct + flags + alloc + compare + register + destroy + (root / 'wasm-build/pdftex-fontmap/test-registration.c').read_text()

with tempfile.TemporaryDirectory(prefix='pdftex-map-') as tmp:
    tmp = Path(tmp)
    path = tmp / 'texk/web2c/pdftexdir/mapfile.c'
    path.parent.mkdir(parents=True)
    path.write_text(source)
    subprocess.run(['patch', '--fuzz=0', '-p1', '-i', str(root / 'wasm-build/pdftex-fontmap/single-probe.patch')], cwd=tmp, check=True)
    outputs = []
    for name, text in [('baseline', source), ('candidate', path.read_text())]:
        c = tmp / f'{name}.c'
        c.write_text(unit(text))
        flags = ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'] if a.sanitize else ['-O2']
        binary = tmp / name
        subprocess.run([a.cc, '-std=c99', '-D_POSIX_C_SOURCE=200809L', *flags, '-I', str(a.source), str(c), str(a.source / 'avl.c'), '-o', str(binary)], check=True)
        try:
            outputs.append(subprocess.check_output([str(binary)], timeout=60))
        except subprocess.TimeoutExpired as error:
            print('Last output:', error.output[-2000:] if error.output else None)
            raise
    assert outputs[0] == outputs[1], 'Registration, diagnostics or traversal differ'
    print('Registration differential passed; output sha256:', hashlib.sha256(outputs[0]).hexdigest())
    print('Upstream mapfile.c sha256:', hashlib.sha256(source.encode()).hexdigest())
