# pdfTeX font-map insertion experiment

This candidate avoids two AVL searches when appending a new map entry. It keeps
the upstream AVL implementation, insertion order, entry layout and replacement /
deletion paths. PS-only lookups for non-embedded/non-Type1 records still use find.
Tree count, not pointer equality, distinguishes a new insertion.

The patch applies to identical `mapfile.c` bytes in both pinned TeX Live sources.
It contains modifications to GPL-covered pdfTeX; the upstream notices and the
engine release's GPL terms apply. This is an unqualified experiment for #138,
not a registered engine release. Existing format and mirror bytes are required.
