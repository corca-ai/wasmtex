/* Execute the included upstream functions with deterministic map operations.
 * Tree traversal, link ownership, warnings, deletion and resets are compared. */
static uint32_t random_state = 138;
static unsigned next_random(void) {
    random_state = random_state * 1664525u + 1013904223u;
    return random_state;
}
static void dump_tree(struct avl_table *tree, unsigned link) {
    struct avl_traverser it;
    fm_entry *fm;
    size_t seen = 0;
    printf("tree %u %zu\n", link, avl_count(tree));
    for (fm = avl_t_first(&it, tree); fm; fm = avl_t_next(&it)) {
        assert(++seen <= avl_count(tree));
        assert(fm->links & link);
        printf("%s %s %d %d %u %u %d\n", fm->tfm_name,
               fm->ps_name ? fm->ps_name : "-", fm->slant, fm->extend,
               fm->type, fm->links, fm->in_use);
    }
}
int main(void) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    for (int round = 0; round < 4; round++) {
        tfm_tree = avl_create(comp_fm_entry_tfm, NULL, NULL);
        ps_tree = avl_create(comp_fm_entry_ps, NULL, NULL);
        assert(tfm_tree && ps_tree);
        for (unsigned i = 0; i < 12000; i++) {
            unsigned n = next_random();
            char tfm[40], ps[40];
            snprintf(tfm, sizeof(tfm), "font%u", i < 2000 ? i : n % 2300);
            snprintf(ps, sizeof(ps), "PS%u", (n >> 9) % 1900);
            fm_entry *fm = new_fm_entry();
            fm->tfm_name = strdup(n % 37 == 0 ? nontfm : tfm);
            fm->ps_name = n % 7 == 0 ? NULL : strdup(ps);
            fm->ff_name = n % 11 == 0 ? NULL : strdup("font.pfb");
            fm->type = (n % 3 == 0 ? F_TRUETYPE : F_TYPE1) |
                       (n % 5 == 0 ? 0 : F_INCLUDED);
            fm->slant = (n >> 17) % 3;
            fm->extend = (n >> 20) % 3;
            suppress_warn = (n >> 23) & 1;
            fm_entry *existing = avl_find(tfm_tree, fm);
            if (existing && n % 13 == 0) existing->in_use = true;
            int mode = i < 2000 ? FM_DUPIGNORE : (n >> 26) % 3;
            int unused = avl_do_entry(fm, mode);
            printf("op %u %d %d\n", i, mode, unused);
            if (unused) delete_fm_entry(fm);
            if (i % 251 == 0) {
                dump_tree(tfm_tree, LINK_TFM);
                dump_tree(ps_tree, LINK_PS);
            }
        }
        dump_tree(tfm_tree, LINK_TFM);
        dump_tree(ps_tree, LINK_PS);
        avl_destroy(tfm_tree, destroy_fm_entry_tfm);
        tfm_tree = NULL;
        avl_destroy(ps_tree, destroy_fm_entry_ps);
        ps_tree = NULL;
    }
    return 0;
}
